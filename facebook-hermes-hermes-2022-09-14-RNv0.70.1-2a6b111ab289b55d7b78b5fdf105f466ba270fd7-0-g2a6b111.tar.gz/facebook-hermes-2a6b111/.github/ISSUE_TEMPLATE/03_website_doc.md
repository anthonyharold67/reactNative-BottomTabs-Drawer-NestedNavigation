---
name: "📗 Website & Documentation Issue"
about: Report a bug or propose an idea to the Hermes website & docs.
title: ''
labels: ''

---

## Description

<!--
  Please provide a clear and concise description of what the bug or the idea is.
  Include screenshots if needed.

  More details make issues more actionable for us and help us prioritize!
-->
