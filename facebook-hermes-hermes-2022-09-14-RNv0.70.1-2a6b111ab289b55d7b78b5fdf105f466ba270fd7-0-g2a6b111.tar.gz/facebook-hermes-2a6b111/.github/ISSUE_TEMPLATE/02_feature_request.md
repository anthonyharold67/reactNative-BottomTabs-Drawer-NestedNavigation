---
name: "🚀 Discussion & Feature Request"
about: Discuss an idea or propose improvement.
title: ''
labels:
- 'enhancement'

---

## Problem

<!--
  Thank you for starting a discussion about Hermes!
  Is your discussion / feature request related to a problem?
  Please provide a clear and concise description of what the problem is.
-->

## Solution

<!--
  Describe the solution you'd like to happen.
  Also, describe the alternatives you've considered.
-->

## Additional Context

<!--
  Add any other context or screenshots about the discussion and feature request.
-->
