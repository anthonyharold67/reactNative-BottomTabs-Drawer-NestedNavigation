let [{a}] = 0
