let [a,,b]=0
