({
    a,
    a:a,
    a:a=a,
    [a]:{a},
    a:some_call()[a],
    a:this.a
} = 0);
