x ** typeof y
